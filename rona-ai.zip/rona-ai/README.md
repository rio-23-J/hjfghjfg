# Rona AI

A bilingual Kurdish/English interface for local image and video
generation through ComfyUI.

## Requirements

- Node.js 20 or newer
- ComfyUI
- A compatible image or video model
- ComfyUI running at http://127.0.0.1:8188

## Installation

1. Copy .env.local.example to .env.local.
2. Install packages:

   npm install

3. Start ComfyUI.
4. Start Rona AI:

   npm run dev

5. Open:

   http://localhost:3000

## Workflows

- workflows/image.json is used for image generation.
- workflows/video.json is used for video generation.
- Workflows must be exported from ComfyUI in API Format.
- Change the checkpoint filename in image.json to match the
  checkpoint installed on your computer.

## ComfyUI address

Change .env.local if ComfyUI uses another address:

COMFYUI_URL=http://127.0.0.1:8188

## Production check

Run:

npm run build
npm start