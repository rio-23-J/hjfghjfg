export type GenerationMode = "image" | "video";

export interface GenerateRequest {
  mode: GenerationMode;
  prompt: string;
  negativePrompt?: string;
  width?: number;
  height?: number;
  steps?: number;
  seed?: number;
}

export interface ComfyOutputFile {
  filename: string;
  subfolder?: string;
  type?: string;
  nodeId: string;
  mediaType: "image" | "video";
}

export interface QueueResponse {
  prompt_id: string;
  number?: number;
  node_errors?: Record<string, unknown>;
}