import fs from "node:fs/promises";
import path from "node:path";

import type {
  ComfyOutputFile,
  GenerateRequest,
  GenerationMode
} from "@/lib/types";

export const COMFYUI_URL = (
  process.env.COMFYUI_URL || "http://127.0.0.1:8188"
).replace(/\/$/, "");

type WorkflowNode = {
  class_type?: string;
  inputs?: Record<string, unknown>;
  _meta?: {
    title?: string;
  };
};

type Workflow = Record<string, WorkflowNode>;

function findNode(
  workflow: Workflow,
  classTypes: string[],
  titleIncludes?: string
): WorkflowNode | undefined {
  const types = new Set(classTypes);

  return Object.values(workflow).find((node) => {
    if (!types.has(node.class_type || "")) {
      return false;
    }

    if (!titleIncludes) {
      return true;
    }

    return node._meta?.title
      ?.toLowerCase()
      .includes(titleIncludes.toLowerCase());
  });
}

function setInput(
  node: WorkflowNode | undefined,
  key: string,
  value: unknown
): void {
  if (node?.inputs && key in node.inputs) {
    node.inputs[key] = value;
  }
}

export async function loadWorkflow(
  mode: GenerationMode
): Promise<Workflow> {
  const workflowPath = path.join(
    process.cwd(),
    "workflows",
    ${mode}.json
  );

  const data = await fs.readFile(workflowPath, "utf8");
  return JSON.parse(data) as Workflow;
}

export function applyGenerationSettings(
  workflow: Workflow,
  request: GenerateRequest
): Workflow {
  const copy = structuredClone(workflow);

  const positiveNode =
    findNode(copy, ["CLIPTextEncode"], "positive") ||
    findNode(copy, ["CLIPTextEncode"]);

  const negativeNode =
    findNode(copy, ["CLIPTextEncode"], "negative") ||
    Object.values(copy).filter(
      (node) => node.class_type === "CLIPTextEncode"
    )[1];

  setInput(positiveNode, "text", request.prompt);
  setInput(
    negativeNode,
    "text",
    request.negativePrompt || "low quality, blurry, watermark"
  );

  const sampler = findNode(copy, [
    "KSampler",
    "KSamplerAdvanced",
    "SamplerCustom",
    "SamplerCustomAdvanced"
  ]);

  setInput(sampler, "seed", request.seed ?? Date.now());
  setInput(sampler, "noise_seed", request.seed ?? Date.now());
  setInput(sampler, "steps", request.steps ?? 24);

  const latent = findNode(copy, [
    "EmptyLatentImage",
    "EmptySD3LatentImage",
    "EmptyHunyuanLatentVideo",
    "EmptyMochiLatentVideo"
  ]);

  setInput(latent, "width", request.width ?? 1024);
  setInput(latent, "height", request.height ?? 1024);

  return copy;
}

export function getOutputFiles(history: unknown): ComfyOutputFile[] {
  if (!history || typeof history !== "object") {
    return [];
  }

  const historyObject = history as Record<
    string,
    {
      outputs?: Record<
        string,
        {
          images?: Array<{
            filename: string;
            subfolder?: string;
            type?: string;
          }>;
          gifs?: Array<{
            filename: string;
            subfolder?: string;
            type?: string;
          }>;
          videos?: Array<{
            filename: string;
            subfolder?: string;
            type?: string;
          }>;
        }
      >;
    }
  >;

  const entry = Object.values(historyObject)[0];
  if (!entry?.outputs) {
    return [];
  }

  const files: ComfyOutputFile[] = [];

  for (const [nodeId, output] of Object.entries(entry.outputs)) {
    for (const image of output.images || []) {
      files.push({
        ...image,
        nodeId,
        mediaType: "image"
      });
    }

    for (const video of [
      ...(output.videos || []),
      ...(output.gifs || [])
    ]) {
      files.push({
        ...video,
        nodeId,
        mediaType: "video"
      });
    }
  }

  return files;
}