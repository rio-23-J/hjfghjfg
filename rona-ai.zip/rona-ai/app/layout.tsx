import type { Metadata } from "next";

import "./globals.css";

export const metadata: Metadata = {
  title: "Rona AI",
  description: "Local AI image and video generation with ComfyUI"
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ku" dir="rtl" suppressHydrationWarning>
      <body>{children}</body>
    </html>
  );
}