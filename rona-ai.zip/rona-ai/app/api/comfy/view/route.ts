import { NextRequest, NextResponse } from "next/server";

import { COMFYUI_URL } from "@/lib/comfy";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const filename = request.nextUrl.searchParams.get("filename");
  const subfolder =
    request.nextUrl.searchParams.get("subfolder") || "";
  const type = request.nextUrl.searchParams.get("type") || "output";

  if (!filename  filename.includes("..")  subfolder.includes("..")) {
    return NextResponse.json(
      {
        error: "Invalid file path."
      },
      {
        status: 400
      }
    );
  }

  try {
    const params = new URLSearchParams({
      filename,
      subfolder,
      type
    });

    const response = await fetch(${COMFYUI_URL}/view?${params}, {
      cache: "no-store"
    });

    if (!response.ok || !response.body) {
      throw new Error(ComfyUI returned ${response.status});
    }

    const headers = new Headers();
    headers.set(
      "Content-Type",
      response.headers.get("Content-Type") ||
        "application/octet-stream"
    );
    headers.set("Cache-Control", "private, max-age=3600");
    headers.set(
      "Content-Disposition",
      inline; filename="${filename.replace(/["\r\n]/g, "")}"
    );

    return new NextResponse(response.body, {
      status: 200,
      headers
    });
  } catch (error) {
    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "Could not load output."
      },
      {
        status: 502
      }
    );
  }
}