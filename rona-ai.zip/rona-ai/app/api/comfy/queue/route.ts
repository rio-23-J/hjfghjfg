import { NextRequest, NextResponse } from "next/server";

import {
  applyGenerationSettings,
  COMFYUI_URL,
  loadWorkflow
} from "@/lib/comfy";
import type { GenerateRequest } from "@/lib/types";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as GenerateRequest;

    if (!body.prompt?.trim()) {
      return NextResponse.json(
        {
          error: "Prompt is required."
        },
        {
          status: 400
        }
      );
    }

    if (body.mode !== "image" && body.mode !== "video") {
      return NextResponse.json(
        {
          error: "Invalid generation mode."
        },
        {
          status: 400
        }
      );
    }

    const workflow = await loadWorkflow(body.mode);
    const prompt = applyGenerationSettings(workflow, {
      ...body,
      prompt: body.prompt.trim()
    });

    const comfyResponse = await fetch(${COMFYUI_URL}/prompt, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        prompt,
        client_id: crypto.randomUUID()
      }),
      cache: "no-store"
    });

    const data = await comfyResponse.json();

    if (!comfyResponse.ok) {
      return NextResponse.json(
        {
          error: "ComfyUI rejected the workflow.",
          details: data
        },
        {
          status: comfyResponse.status
        }
      );
    }

    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "Could not queue the workflow."
      },
      {
        status: 500
      }
    );
  }
}