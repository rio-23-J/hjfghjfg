import { NextResponse } from "next/server";

import { COMFYUI_URL, getOutputFiles } from "@/lib/comfy";

export const dynamic = "force-dynamic";

interface RouteContext {
  params: Promise<{
    promptId: string;
  }>;
}

export async function GET(
  _request: Request,
  context: RouteContext
) {
  try {
    const { promptId } = await context.params;

    if (!/^[a-zA-Z0-9-]+$/.test(promptId)) {
      return NextResponse.json(
        {
          error: "Invalid prompt ID."
        },
        {
          status: 400
        }
      );
    }

    const response = await fetch(
      ${COMFYUI_URL}/history/${encodeURIComponent(promptId)},
      {
        cache: "no-store"
      }
    );

    if (!response.ok) {
      throw new Error(ComfyUI returned ${response.status});
    }

    const history = await response.json();
    const files = getOutputFiles(history);

    return NextResponse.json({
      completed: files.length > 0,
      files
    });
  } catch (error) {
    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "Could not read generation history."
      },
      {
        status: 500
      }
    );
  }
}