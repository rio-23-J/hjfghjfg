import fs from "node:fs/promises";
import path from "node:path";

import { NextResponse } from "next/server";

export const runtime = "nodejs";

export async function GET() {
  const workflowDirectory = path.join(process.cwd(), "workflows");

  try {
    const files = await fs.readdir(workflowDirectory);

    return NextResponse.json({
      image: files.includes("image.json"),
      video: files.includes("video.json")
    });
  } catch {
    return NextResponse.json({
      image: false,
      video: false
    });
  }
}