import { RonaApp } from "@/components/rona-app";

export default function HomePage() {
  return <RonaApp />;
}