"use client";

import {
  FormEvent,
  useCallback,
  useEffect,
  useMemo,
  useState
} from "react";

import { dictionaries, type Locale } from "@/lib/i18n";
import type {
  ComfyOutputFile,
  GenerationMode,
  QueueResponse
} from "@/lib/types";

type Theme = "dark" | "light";

interface GalleryItem extends ComfyOutputFile {
  id: string;
  url: string;
  prompt: string;
}

function makeFileUrl(file: ComfyOutputFile): string {
  const params = new URLSearchParams({
    filename: file.filename,
    subfolder: file.subfolder || "",
    type: file.type || "output"
  });

  return /api/comfy/view?${params.toString()};
}

function sleep(milliseconds: number) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

export function RonaApp() {
  const [locale, setLocale] = useState<Locale>("ku");
  const [theme, setTheme] = useState<Theme>("dark");
  const [mode, setMode] = useState<GenerationMode>("image");
  const [prompt, setPrompt] = useState("");
  const [negativePrompt, setNegativePrompt] = useState(
    "low quality, blurry, watermark"
  );
  const [width, setWidth] = useState(1024);
  const [height, setHeight] = useState(1024);
  const [steps, setSteps] = useState(24);
  const [seed, setSeed] = useState(-1);
  const [connected, setConnected] = useState<boolean | null>(null);
  const [generating, setGenerating] = useState(false);
  const [message, setMessage] = useState("");
  const [gallery, setGallery] = useState<GalleryItem[]>([]);

  const text = dictionaries[locale];
  const direction = locale === "ku" ? "rtl" : "ltr";

  useEffect(() => {
    const savedTheme = localStorage.getItem("rona-theme") as Theme | null;
    const savedLocale = localStorage.getItem(
      "rona-locale"
    ) as Locale | null;

    if (savedTheme === "dark" || savedTheme === "light") {
      setTheme(savedTheme);
    }

    if (savedLocale === "ku" || savedLocale === "en") {
      setLocale(savedLocale);
    }

    try {
      const savedGallery = localStorage.getItem("rona-gallery");
      if (savedGallery) {
        setGallery(JSON.parse(savedGallery) as GalleryItem[]);
      }
    } catch {
      localStorage.removeItem("rona-gallery");
    }
  }, []);

  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = direction;
    document.documentElement.dataset.theme = theme;
    localStorage.setItem("rona-theme", theme);
    localStorage.setItem("rona-locale", locale);
  }, [direction, locale, theme]);

  useEffect(() => {
    localStorage.setItem("rona-gallery", JSON.stringify(gallery));
  }, [gallery]);

  const checkConnection = useCallback(async () => {
    try {
      const response = await fetch("/api/health", {
        cache: "no-store"
      });
      setConnected(response.ok);
    } catch {
      setConnected(false);
    }
  }, []);

  useEffect(() => {
    void checkConnection();
    const timer = window.setInterval(checkConnection, 15000);
    return () => window.clearInterval(timer);
  }, [checkConnection]);

  const dimensions = useMemo(
    () =>
      mode === "image"
        ? [
            [512][512],
            [768][768],
            [1024][1024],
            [1024][768],
            [768][1024]
          ]
        : [
            [512][512],
            [768][432],
            [832][480]
          ],
    [mode]
  );

  async function pollForResult(promptId: string) {
    for (let attempt = 0; attempt < 180; attempt += 1) {
      const response = await fetch(
        /api/comfy/history/${encodeURIComponent(promptId)},
        {
          cache: "no-store"
        }
      );

      if (!response.ok) {
        const error = await response.json().catch(() => null);
        throw new Error(error?.error || "History request failed.");
      }

      const data = (await response.json()) as {
        completed: boolean;
        files: ComfyOutputFile[];
      };

      if (data.completed) {
        return data.files;
      }

      await sleep(2000);
    }

    throw new Error("Generation timed out.");
  }
  async function generate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage("");

    if (!prompt.trim()) {
      setMessage(text.emptyPrompt);
      return;
    }

    setGenerating(true);

    try {
      const selectedSeed =
        seed < 0
          ? Math.floor(Math.random() * 2_147_483_647)
          : seed;

      const response = await fetch("/api/comfy/queue", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          mode,
          prompt,
          negativePrompt,
          width,
          height,
          steps,
          seed: selectedSeed
        })
      });

      const queued = (await response.json()) as QueueResponse & {
        error?: string;
        details?: unknown;
      };

      if (!response.ok || !queued.prompt_id) {
        throw new Error(queued.error || "Could not queue generation.");
      }

      const files = await pollForResult(queued.prompt_id);

      const items = files.map((file, index) => ({
        ...file,
        id: ${queued.prompt_id}-${file.nodeId}-${index},
        url: makeFileUrl(file),
        prompt
      }));

      setGallery((current) => [...items, ...current]);
    } catch (error) {
      setMessage(
        ${text.error}: ${
          error instanceof Error ? error.message : "Unknown error"
        }
      );
    } finally {
      setGenerating(false);
    }
  }

  function chooseDimensions(value: string) {
    const [nextWidth, nextHeight] = value.split("x").map(Number);
    setWidth(nextWidth);
    setHeight(nextHeight);
  }

  function removeItem(id: string) {
    setGallery((current) => current.filter((item) => item.id !== id));
  }

  return (
    <main className="app-shell" dir={direction}>
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark">R</div>
          <div>
            <strong>Rona AI</strong>
            <span>{text.brandDescription}</span>
          </div>
        </div>

        <div className="header-actions">
          <div
            className={connection ${
              connected ? "connected" : "disconnected"
            }}
          >
            <span className="status-dot" />
            {connected ? text.ready : text.offline}
          </div>

          <button
            className="icon-button"
            type="button"
            onClick={() =>
              setTheme((current) =>
                current === "dark" ? "light" : "dark"
              )
            }
            aria-label={text.theme}
          >
            {theme === "dark" ? "☀" : "☾"}
          </button>

          <button
            className="language-button"
            type="button"
            onClick={() =>
              setLocale((current) =>
                current === "ku" ? "en" : "ku"
              )
            }
          >
            {locale === "ku" ? "EN" : "کوردی"}
          </button>
        </div>
      </header>

      <section className="hero">
        <p className="eyebrow">LOCAL GENERATIVE STUDIO</p>
        <h1>
          <span>Rona</span> AI
        </h1>
        <p>{text.brandDescription}</p>
      </section>

      <section className="workspace">
        <form className="generator-card" onSubmit={generate}>
          <div className="mode-switcher">
            <button
              type="button"
              className={mode === "image" ? "active" : ""}
              onClick={() => setMode("image")}
            >
              ◫ {text.image}
            </button>
            <button
              type="button"
              className={mode === "video" ? "active" : ""}
              onClick={() => setMode("video")}
            >
              ▷ {text.video}
            </button>
          </div>
          <label>
            <span>{text.prompt}</span>
            <textarea
              value={prompt}
              onChange={(event) => setPrompt(event.target.value)}
              placeholder={text.promptPlaceholder}
              rows={6}
              maxLength={3000}
            />
            <small>{prompt.length}/3000</small>
          </label>

          <label>
            <span>{text.negativePrompt}</span>
            <textarea
              value={negativePrompt}
              onChange={(event) =>
                setNegativePrompt(event.target.value)
              }
              placeholder={text.negativePlaceholder}
              rows={3}
            />
          </label>

          <div className="form-grid">
            <label>
              <span>
                {text.width} × {text.height}
              </span>
              <select
                value={${width}x${height}}
                onChange={(event) =>
                  chooseDimensions(event.target.value)
                }
              >
                {dimensions.map(([itemWidth, itemHeight]) => (
                  <option
                    value={${itemWidth}x${itemHeight}}
                    key={${itemWidth}x${itemHeight}}
                  >
                    {itemWidth} × {itemHeight}
                  </option>
                ))}
              </select>
            </label>

            <label>
              <span>{text.steps}</span>
              <input
                type="number"
                min={1}
                max={150}
                value={steps}
                onChange={(event) =>
                  setSteps(Number(event.target.value))
                }
              />
            </label>

            <label>
              <span>{text.seed}</span>
              <div className="seed-row">
                <input
                  type="number"
                  min={-1}
                  value={seed}
                  onChange={(event) =>
                    setSeed(Number(event.target.value))
                  }
                />
                <button
                  type="button"
                  onClick={() =>
                    setSeed(
                      Math.floor(Math.random() * 2_147_483_647)
                    )
                  }
                >
                  ↻
                </button>
              </div>
            </label>
          </div>

          {message && <div className="error-message">{message}</div>}

          <button
            className="generate-button"
            type="submit"
            disabled={generating || connected === false}
          >
            {generating ? (
              <>
                <span className="spinner" />
                {text.generating}
              </>
            ) : (
              <>✦ {text.generate}</>
            )}
          </button>

          <p className="workflow-help">{text.workflowHelp}</p>
        </form>

        <section className="gallery-card">
          <div className="section-heading">
            <div>
              <span>{text.result}</span>
              <h2>{text.gallery}</h2>
            </div>
            <strong>{gallery.length}</strong>
          </div>

          {gallery.length === 0 ? (
            <div className="empty-state">
              <div>✦</div>
              <p>{text.noResults}</p>
            </div>
          ) : (
            <div className="gallery-grid">
              {gallery.map((item) => (
                <article className="gallery-item" key={item.id}>
                  {item.mediaType === "video" ? (
                    &lt;video src={item.url} controls /&gt;
                  ) : (
                    <img
                      src={item.url}
                      alt={item.prompt}
                      loading="lazy"
                    />
                  )}
                  <div className="gallery-overlay">
                    <p>{item.prompt}</p>
                    <div>
                      <a href={item.url} download={item.filename}>
                        {text.download}
                      </a>
                      <button
                        type="button"
                        onClick={() => removeItem(item.id)}
                      >
                        {text.remove}
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </section>

      <footer>
        <span>Rona AI</span>
        <span>ComfyUI Local Studio</span>
      </footer>
    </main>
  );
}